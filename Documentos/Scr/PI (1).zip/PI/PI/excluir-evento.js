document.addEventListener('DOMContentLoaded', function() {
    // Elementos do DOM
    const eventSelect = document.getElementById('eventSelect');
    const reasonText = document.getElementById('reasonText');
    const confirmCheckbox = document.getElementById('confirmCheckbox');
    
    // Botões de navegação
    const nextToStep2Btn = document.getElementById('nextToStep2');
    const backToStep1Btn = document.getElementById('backToStep1');
    const nextToStep3Btn = document.getElementById('nextToStep3');
    const backToStep2Btn = document.getElementById('backToStep2');
    const confirmDeleteBtn = document.getElementById('confirmDelete');
    
    // Seções do formulário
    const step1 = document.getElementById('step1');
    const step2 = document.getElementById('step2');
    const step3 = document.getElementById('step3');

    // Carregar eventos no select
    function loadEvents() {
        const eventos = JSON.parse(localStorage.getItem('eventos')) || [];
        
        eventSelect.innerHTML = '<option value="">Selecione um evento...</option>';
        
        eventos.forEach(evento => {
            const option = document.createElement('option');
            option.value = evento.id;
            option.textContent = `${evento.title} - ${formatDate(evento.date)}`;
            eventSelect.appendChild(option);
        });
    }

    // Função para formatar data
    function formatDate(dateString) {
        const options = { day: '2-digit', month: '2-digit', year: 'numeric' };
        return new Date(dateString).toLocaleDateString('pt-BR', options);
    }

    // Navegação entre passos
    nextToStep2Btn.addEventListener('click', function() {
        if (eventSelect.value) {
            step1.classList.add('hidden');
            step2.classList.remove('hidden');
        } else {
            alert('Por favor, selecione um evento');
        }
    });

    backToStep1Btn.addEventListener('click', function() {
        step2.classList.add('hidden');
        step1.classList.remove('hidden');
    });

    nextToStep3Btn.addEventListener('click', function() {
        if (reasonText.value.trim()) {
            step2.classList.add('hidden');
            step3.classList.remove('hidden');
        } else {
            alert('Por favor, informe o motivo do cancelamento');
        }
    });

    backToStep2Btn.addEventListener('click', function() {
        step3.classList.add('hidden');
        step2.classList.remove('hidden');
    });

    // Confirmar exclusão
    confirmDeleteBtn.addEventListener('click', function() {
        if (!confirmCheckbox.checked) {
            alert('Por favor, marque a confirmação para excluir o evento');
            return;
        }

        const eventId = eventSelect.value;
        const motivo = reasonText.value.trim();
        
        // Remover evento do localStorage
        let eventos = JSON.parse(localStorage.getItem('eventos')) || [];
        eventos = eventos.filter(evento => evento.id !== eventId);
        localStorage.setItem('eventos', JSON.stringify(eventos));
        
        alert('Evento excluído com sucesso!');
        window.location.href = 'dashboard.html';
    });

    // Carregar eventos quando a página é aberta
    loadEvents();
    // Adicione isto no final do seu arquivo JS existente

// Navegação do Menu Lateral
document.querySelector('.create-event-btn').addEventListener('click', function() {
    window.location.href = 'criar-evento.html';
});

document.querySelectorAll('.menu-item').forEach(item => {
    item.addEventListener('click', function() {
        const text = this.textContent || this.innerText;
        
        if (text.includes('Dashboard')) {
            window.location.href = 'dashboard.html';
        } else if (text.includes('Editar')) {
            window.location.href = 'editar-evento.html';
        } else if (text.includes('Excluir')) {
            window.location.href = 'excluir-evento.html';
        }
    });
});
});