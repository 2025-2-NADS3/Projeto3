-- Inicialização do banco para o projeto `simple_crud_login`
-- Este script é executado automaticamente pelo container do MySQL ao subir (montado em /docker-entrypoint-initdb.d)

CREATE DATABASE IF NOT EXISTS simple_crud_login;
USE simple_crud_login;

CREATE TABLE IF NOT EXISTS comedoria_usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
