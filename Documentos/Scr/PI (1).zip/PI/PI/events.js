// events.js - Gerencia o armazenamento e manipulação de eventos

/**
 * Salva um novo evento no localStorage
 * @param {Object} evento - O objeto evento a ser salvo
 * @returns {boolean} - True se salvou com sucesso, False caso contrário
 */
export function salvarEvento(evento) {
    try {
        // Adiciona ID e timestamp se não existirem
        if (!evento.id) evento.id = Date.now().toString();
        if (!evento.createdAt) evento.createdAt = new Date().toISOString();
        
        // Obtém eventos existentes
        const eventos = carregarEventos();
        
        // Adiciona o novo evento
        eventos.unshift(evento);
        
        // Salva no localStorage
        localStorage.setItem('eventos', JSON.stringify(eventos));
        
        return true;
    } catch (error) {
        console.error('Erro ao salvar evento:', error);
        return false;
    }
}

/**
 * Carrega todos os eventos do localStorage
 * @returns {Array} - Lista de eventos
 */
export function carregarEventos() {
    try {
        return JSON.parse(localStorage.getItem('eventos')) || [];
    } catch (error) {
        console.error('Erro ao carregar eventos:', error);
        return [];
    }
}

/**
 * Remove um evento pelo ID
 * @param {string} id - ID do evento a ser removido
 * @returns {boolean} - True se removeu com sucesso, False caso contrário
 */
export function removerEvento(id) {
    try {
        let eventos = carregarEventos();
        eventos = eventos.filter(evento => evento.id !== id);
        localStorage.setItem('eventos', JSON.stringify(eventos));
        return true;
    } catch (error) {
        console.error('Erro ao remover evento:', error);
        return false;
    }
}

/**
 * Renderiza os eventos no container especificado
 * @param {HTMLElement} container - Elemento HTML onde os eventos serão renderizados
 */
export function renderizarEventos(container) {
    if (!container) return;
    
    const eventos = carregarEventos();
    
    if (eventos.length === 0) {
        container.innerHTML = `
            <div class="sem-eventos">
                <p>Nenhum evento cadastrado ainda</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = '';
    
    eventos.forEach(evento => {
        const eventoElement = document.createElement('div');
        eventoElement.className = 'evento-card';
        
        // Verifica se a imagem existe e é uma string base64 válida
        let imageUrl = 'https://via.placeholder.com/300x160?text=Sem+Imagem';
        if (evento.image && evento.image.startsWith('data:image')) {
            imageUrl = evento.image;
        }
        
        eventoElement.innerHTML = `
            <div class="evento-imagem" style="background-image: url('${imageUrl}')"></div>
            <div class="evento-info">
                <h3>${evento.title || 'Evento sem título'}</h3>
                ${evento.category ? `<span class="evento-categoria">${evento.category}</span>` : ''}
                <div class="evento-meta">
                    <span>${formatarData(evento.date)}</span>
                    ${evento.startTime && evento.endTime ? `<span>${evento.startTime} - ${evento.endTime}</span>` : ''}
                </div>
                ${evento.location ? `<div class="evento-meta"><span>${evento.location}</span></div>` : ''}
                ${evento.description ? `<p class="evento-descricao">${evento.description}</p>` : ''}
                ${evento.participants ? `<div class="evento-participantes">${evento.participants.length} participantes</div>` : ''}
            </div>
        `;
        container.appendChild(eventoElement);
    });
}

/**
 * Formata uma data para o padrão brasileiro
 * @param {string} dataString - Data no formato ISO ou similar
 * @returns {string} - Data formatada
 */
function formatarData(dataString) {
    if (!dataString) return 'Data não definida';
    try {
        const options = { day: '2-digit', month: '2-digit', year: 'numeric' };
        return new Date(dataString).toLocaleDateString('pt-BR', options);
    } catch {
        return dataString;
    }
}

/**
 * Atualiza os contadores no dashboard
 */
export function atualizarContadores() {
    const eventos = carregarEventos();
    
    // Atualizar contagem de eventos
    const eventCountElement = document.querySelector('.dashboard-card:nth-child(2) .dashboard-card-value');
    if (eventCountElement) {
        eventCountElement.textContent = eventos.length;
    }

    // Atualizar contagem de participantes
    const participantCountElement = document.querySelector('.dashboard-card:nth-child(3) .dashboard-card-value');
    if (participantCountElement) {
        const totalParticipants = eventos.reduce((total, evento) => {
            return total + (evento.participants ? evento.participants.length : 0);
        }, 0);
        participantCountElement.textContent = totalParticipants;
    }
}