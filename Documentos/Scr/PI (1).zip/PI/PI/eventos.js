// eventos.js - Gerencia o armazenamento e recuperação de eventos

/**
 * Salva um novo evento no localStorage
 * @param {Object} evento - O objeto evento a ser salvo
 */
function salvarEvento(evento) {
    try {
        // Adiciona ID e timestamp se não existirem
        if (!evento.id) evento.id = Date.now().toString();
        if (!evento.createdAt) evento.createdAt = new Date().toISOString();
        
        // Obtém eventos existentes ou array vazio
        const eventos = JSON.parse(localStorage.getItem('eventos')) || [];
        
        // Adiciona o novo evento no início do array
        eventos.unshift(evento);
        
        // Salva no localStorage
        localStorage.setItem('eventos', JSON.stringify(eventos));
        
        return true;
    } catch (error) {
        console.error('Erro ao salvar evento:', error);
        return false;
    }
}

/**
 * Recupera todos os eventos do localStorage
 * @return {Array} Lista de eventos
 */
function carregarEventos() {
    try {
        return JSON.parse(localStorage.getItem('eventos')) || [];
    } catch (error) {
        console.error('Erro ao carregar eventos:', error);
        return [];
    }
}

/**
 * Remove um evento pelo ID
 * @param {string} id - ID do evento a ser removido
 */
function removerEvento(id) {
    try {
        let eventos = carregarEventos();
        eventos = eventos.filter(evento => evento.id !== id);
        localStorage.setItem('eventos', JSON.stringify(eventos));
        return true;
    } catch (error) {
        console.error('Erro ao remover evento:', error);
        return false;
    }
}

/**
 * Renderiza os eventos no container especificado
 * @param {HTMLElement} container - Elemento HTML onde os eventos serão renderizados
 */
function renderizarEventos(container) {
    if (!container) return;
    
    const eventos = carregarEventos();
    
    if (eventos.length === 0) {
        container.innerHTML = `
            <div class="sem-eventos">
                <p>Nenhum evento cadastrado ainda</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = '';
    
    eventos.forEach(evento => {
        const eventoElement = document.createElement('div');
        eventoElement.className = 'evento-card';
        eventoElement.innerHTML = `
            <div class="evento-imagem" style="background-image: url(${evento.image || 'https://via.placeholder.com/300x160?text=Sem+Imagem'})"></div>
            <div class="evento-info">
                <h3>${evento.title || 'Evento sem título'}</h3>
                ${evento.category ? `<span class="evento-categoria">${evento.category}</span>` : ''}
                <div class="evento-meta">
                    <span>${formatarData(evento.date)}</span>
                    ${evento.startTime && evento.endTime ? `<span>${evento.startTime} - ${evento.endTime}</span>` : ''}
                </div>
                ${evento.location ? `<div class="evento-meta"><span>${evento.location}</span></div>` : ''}
                ${evento.description ? `<p class="evento-descricao">${evento.description}</p>` : ''}
            </div>
        `;
        container.appendChild(eventoElement);
    });
}

/**
 * Formata uma data para o padrão brasileiro
 * @param {string} dataString - Data no formato ISO ou similar
 * @return {string} Data formatada
 */
function formatarData(dataString) {
    if (!dataString) return 'Data não definida';
    try {
        const options = { day: '2-digit', month: '2-digit', year: 'numeric' };
        return new Date(dataString).toLocaleDateString('pt-BR', options);
    } catch {
        return dataString;
    }
}

// Exporta as funções para uso em outros arquivos
if (typeof module !== 'undefined' && module.exports) {
    // Para Node.js
    module.exports = { salvarEvento, carregarEventos, removerEvento, renderizarEventos };
} else {
    // Para navegador
    window.eventosAPI = { salvarEvento, carregarEventos, removerEvento, renderizarEventos };
}