// main.js - Lógica principal da aplicação
import { 
    salvarEvento, 
    carregarEventos, 
    renderizarEventos, 
    atualizarContadores 
} from './events.js';

document.addEventListener('DOMContentLoaded', function() {
    const currentPage = window.location.pathname.split('/').pop();

    // ========== FUNÇÕES AUXILIARES ==========
    
    function showError(fieldId, message) {
        const errorElement = document.getElementById(fieldId + 'Error') || document.createElement('div');
        errorElement.textContent = message;
        errorElement.style.color = '#EA191C';
        errorElement.style.fontSize = '12px';
        errorElement.style.marginTop = '5px';
        errorElement.style.display = 'block';
        errorElement.className = 'error-message';
        
        const field = document.getElementById(fieldId);
        if (field) {
            if (!field.nextElementSibling || !field.nextElementSibling.classList.contains('error-message')) {
                field.parentNode.insertBefore(errorElement, field.nextSibling);
            }
            field.style.borderColor = '#EA191C';
        }
    }

    function clearErrors() {
        const errorMessages = document.querySelectorAll('.error-message');
        errorMessages.forEach(msg => msg.remove());
        
        const inputs = document.querySelectorAll('input, textarea, select');
        inputs.forEach(input => {
            input.style.borderColor = '#E6E6F0';
        });
    }

    function isValidEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    function applyMask(input, mask) {
        const value = input.value.replace(/\D/g, '');
        let result = '';
        let charIndex = 0;
        
        for (let i = 0; i < mask.length; i++) {
            if (mask[i] === '0') {
                if (value[charIndex]) {
                    result += value[charIndex++];
                } else {
                    break;
                }
            } else {
                result += mask[i];
            }
        }
        
        input.value = result;
    }

    // ========== PÁGINA DE LOGIN ==========
    if (currentPage === 'index.html' || currentPage === '') {
        const loginForm = document.getElementById('loginForm');
        const registerLink = document.getElementById('registerLink');
        
        if (loginForm) {
            loginForm.addEventListener('submit', function(e) {
                e.preventDefault();
                clearErrors();
                
                const email = document.getElementById('email').value.trim();
                const password = document.getElementById('password').value.trim();
                
                let isValid = true;
                
                if (!email) {
                    showError('email', 'Por favor, insira seu email');
                    isValid = false;
                } else if (!isValidEmail(email)) {
                    showError('email', 'Por favor, insira um email válido');
                    isValid = false;
                }
                
                if (!password) {
                    showError('password', 'Por favor, insira sua senha');
                    isValid = false;
                } else if (password.length < 6) {
                    showError('password', 'A senha deve ter pelo menos 6 caracteres');
                    isValid = false;
                }
                
                if (isValid) {
                    const loginButton = document.querySelector('.login-button');
                    loginButton.disabled = true;
                    loginButton.innerHTML = 'Entrando...';
                    
                    setTimeout(function() {
                        window.location.href = 'dashboard.html';
                    }, 1500);
                }
            });
        }
        
        if (registerLink) {
            registerLink.addEventListener('click', function(e) {
                e.preventDefault();
                window.location.href = 'cadastro.html';
            });
        }
    }
    
    // ========== PÁGINA DE CADASTRO ==========
    else if (currentPage === 'cadastro.html') {
        const registerForm = document.getElementById('registerForm');
        const loginLink = document.getElementById('loginLink');
        
        if (registerForm) {
            registerForm.addEventListener('submit', function(e) {
                e.preventDefault();
                clearErrors();
                
                const fullname = document.getElementById('fullname').value.trim();
                const email = document.getElementById('email').value.trim();
                const cpf = document.getElementById('cpf').value.trim();
                const phone = document.getElementById('phone').value.trim();
                const password = document.getElementById('password').value.trim();
                const confirmPassword = document.getElementById('confirmPassword').value.trim();
                
                let isValid = true;
                
                if (!fullname) {
                    showError('fullname', 'Por favor, insira seu nome completo');
                    isValid = false;
                }
                
                if (!email) {
                    showError('email', 'Por favor, insira seu email');
                    isValid = false;
                } else if (!isValidEmail(email)) {
                    showError('email', 'Por favor, insira um email válido');
                    isValid = false;
                }
                
                if (!cpf) {
                    showError('cpf', 'Por favor, insira seu CPF');
                    isValid = false;
                } else if (cpf.length < 14) {
                    showError('cpf', 'CPF incompleto');
                    isValid = false;
                }
                
                if (!phone) {
                    showError('phone', 'Por favor, insira seu telefone');
                    isValid = false;
                } else if (phone.length < 15) {
                    showError('phone', 'Telefone incompleto');
                    isValid = false;
                }
                
                if (!password) {
                    showError('password', 'Por favor, insira sua senha');
                    isValid = false;
                } else if (password.length < 6) {
                    showError('password', 'A senha deve ter pelo menos 6 caracteres');
                    isValid = false;
                }
                
                if (!confirmPassword) {
                    showError('confirmPassword', 'Por favor, confirme sua senha');
                    isValid = false;
                } else if (password !== confirmPassword) {
                    showError('confirmPassword', 'As senhas não coincidem');
                    isValid = false;
                }
                
                if (isValid) {
                    const registerButton = registerForm.querySelector('button[type="submit"]');
                    registerButton.disabled = true;
                    registerButton.innerHTML = 'Registrando...';
                    
                    setTimeout(function() {
                        alert('Cadastro realizado com sucesso!');
                        window.location.href = 'dashboard.html';
                    }, 1500);
                }
            });
        }
        
        if (loginLink) {
            loginLink.addEventListener('click', function(e) {
                e.preventDefault();
                window.location.href = 'index.html';
            });
        }
        
        const cpfInput = document.getElementById('cpf');
        const phoneInput = document.getElementById('phone');
        
        if (cpfInput) {
            cpfInput.addEventListener('input', function(e) {
                applyMask(e.target, '000.000.000-00');
            });
        }
        
        if (phoneInput) {
            phoneInput.addEventListener('input', function(e) {
                applyMask(e.target, '(00) 00000-0000');
            });
        }
    }
    
    // ========== PÁGINA DO DASHBOARD ==========
    else if (currentPage === 'dashboard.html') {
        // Configurar botões de criação de evento
        document.querySelectorAll('.dashboard-create-btn, .dashboard-report-btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                window.location.href = 'criar-evento.html';
            });
        });
        
        // Configurar itens do menu
        document.querySelectorAll('.dashboard-menu-item').forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                const text = this.textContent || '';
                
                if (text.includes('Dashboard')) {
                    window.location.href = 'dashboard.html';
                } else if (text.includes('Editar')) {
                    window.location.href = 'editar-evento.html';
                } else if (text.includes('Excluir')) {
                    window.location.href = 'excluir-evento.html';
                }
            });
        });
        
        // Renderizar eventos ao carregar
        renderizarEventos(document.getElementById('eventosContainer'));
        atualizarContadores();
    }
    
    // ========== PÁGINA DE CRIAR EVENTO ==========
    else if (currentPage === 'criar-evento.html') {
        // Configurar botão de criação de evento
        document.querySelector('.dashboard-create-btn')?.addEventListener('click', function(e) {
            e.preventDefault();
            window.location.href = 'criar-evento.html';
        });
        
        // Configurar itens do menu
        document.querySelectorAll('.dashboard-menu-item').forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                const text = this.textContent || '';
                
                if (text.includes('Dashboard')) {
                    window.location.href = 'dashboard.html';
                } else if (text.includes('Editar')) {
                    window.location.href = 'editar-evento.html';
                } else if (text.includes('Excluir')) {
                    window.location.href = 'excluir-evento.html';
                }
            });
            
            // Marcar "Editar evento" como ativo
            if (item.textContent.includes('Editar evento')) {
                item.classList.add('active');
            } else {
                item.classList.remove('active');
            }
        });

        // ========== GERENCIAMENTO DE IMAGEM ==========
        const eventImageInput = document.getElementById('eventImage');
        const imagePreview = document.getElementById('imagePreview');
        
        if (eventImageInput && imagePreview) {
            eventImageInput.addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (!file) return;

                // Validação do tipo de arquivo
                if (!file.type.match('image.*')) {
                    showError('eventImage', 'Por favor, selecione um arquivo de imagem (JPEG ou PNG)');
                    return;
                }

                // Validação do tamanho do arquivo (máx 2MB)
                if (file.size > 2 * 1024 * 1024) {
                    showError('eventImage', 'A imagem deve ter menos de 2MB');
                    return;
                }

                // Criar preview
                const reader = new FileReader();
                reader.onload = function(e) {
                    const img = new Image();
                    img.onload = function() {
                        // Validação de dimensões (opcional)
                        const minWidth = 600;
                        const minHeight = 300;
                        const aspectRatio = 16/9;
                        const tolerance = 0.1; // 10% de tolerância
                        
                        const actualAspectRatio = img.width / img.height;
                        const ratioDifference = Math.abs(actualAspectRatio - aspectRatio);
                        
                        if (ratioDifference > tolerance) {
                            showError('eventImage', `Proporção recomendada é 16:9 (${img.width}x${img.height}px detectado)`);
                        } else if (img.width < minWidth || img.height < minHeight) {
                            showError('eventImage', `Resolução mínima recomendada: ${minWidth}x${minHeight}px`);
                        } else {
                            clearErrors();
                        }

                        // Criar preview
                        imagePreview.innerHTML = `
                            <img src="${e.target.result}" alt="Preview da imagem">
                            <div class="image-upload-requirements">
                                ${img.width}x${img.height}px (${Math.round(actualAspectRatio*100)/100}:1)
                            </div>
                        `;
                        imagePreview.classList.add('has-image');
                    };
                    img.src = e.target.result;
                };
                reader.readAsDataURL(file);
            });
        }

        // ========== GERENCIAMENTO DE PARTICIPANTES ==========
const participantsContainer = document.getElementById('participantsContainer');
const newParticipantInput = document.getElementById('newParticipant');
const addParticipantBtn = document.getElementById('addParticipantBtn');
const participantsListInput = document.getElementById('participantsList');
let participants = [];

function updateParticipantsList() {
    if (participantsListInput) {
        participantsListInput.value = JSON.stringify(participants);
    }
}

function renderParticipants() {
    if (!participantsContainer) return;
    
    participantsContainer.innerHTML = '';
    participants.forEach((participant, index) => {
        const participantElement = document.createElement('div');
        participantElement.className = 'participant-item';
        participantElement.innerHTML = `
            <span class="participant-name">${participant}</span>
            <button type="button" class="remove-participant" data-index="${index}">×</button>
        `;
        participantsContainer.appendChild(participantElement);
    });
    updateParticipantsList();
}

// Adicionar participante
if (addParticipantBtn && newParticipantInput) {
    addParticipantBtn.addEventListener('click', function() {
        const participantName = newParticipantInput.value.trim();
        if (participantName) {
            participants.push(participantName);
            newParticipantInput.value = '';
            renderParticipants();
        }
    });

    // Adicionar com Enter
    newParticipantInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            addParticipantBtn.click();
        }
    });
}

// Remover participante
if (participantsContainer) {
    participantsContainer.addEventListener('click', function(e) {
        if (e.target.classList.contains('remove-participant')) {
            const index = parseInt(e.target.getAttribute('data-index'));
            if (!isNaN(index) && index >= 0 && index < participants.length) {
                participants.splice(index, 1);
                renderParticipants();
            }
        }
    });
}

        // ========== VALIDAÇÃO DO FORMULÁRIO ==========
        const eventForm = document.getElementById('eventForm');
        if (eventForm) {
            eventForm.addEventListener('submit', function(e) {
                e.preventDefault();
                clearErrors();
                
                // Obter valores dos campos
                const eventTitle = document.getElementById('eventTitle')?.value.trim();
                const eventDate = document.getElementById('eventDate')?.value;
                const startTime = document.getElementById('startTime')?.value;
                const endTime = document.getElementById('endTime')?.value;
                const eventLocation = document.getElementById('eventLocation')?.value.trim();
                const eventChair = document.getElementById('eventChair')?.value.trim();
                const eventPresenter = document.getElementById('eventPresenter')?.value.trim();
                const eventCategory = document.getElementById('eventCategory')?.value;
                const eventDescription = document.getElementById('eventDescription')?.value.trim();
                const eventImage = document.getElementById('eventImage')?.files[0];
                
                // Validação
                let isValid = true;
                
                if (!eventTitle) {
                    showError('eventTitle', 'Por favor, insira o título do evento');
                    isValid = false;
                } else if (eventTitle.length < 8) {
                    showError('eventTitle', 'O título deve ter pelo menos 8 caracteres');
                    isValid = false;
                }
                
                if (!eventDate) {
                    showError('eventDate', 'Por favor, selecione a data do evento');
                    isValid = false;
                }
                
                if (!startTime || !endTime) {
                    showError('startTime', 'Por favor, selecione os horários');
                    isValid = false;
                } else if (startTime >= endTime) {
                    showError('startTime', 'O horário final deve ser após o horário inicial');
                    isValid = false;
                }
                
                if (!eventLocation) {
                    showError('eventLocation', 'Por favor, insira o local do evento');
                    isValid = false;
                }
                
                if (!eventChair) {
                    showError('eventChair', 'Por favor, insira quem presidirá o evento');
                    isValid = false;
                }
                
                if (!eventPresenter) {
                    showError('eventPresenter', 'Por favor, insira quem apresentará o evento');
                    isValid = false;
                }
                
                if (participants.length === 0) {
                    showError('participantsContainer', 'Por favor, adicione pelo menos um participante');
                    isValid = false;
                }
                
                if (!eventCategory) {
                    showError('eventCategory', 'Por favor, selecione uma categoria');
                    isValid = false;
                }
                
                if (!eventDescription) {
                    showError('eventDescription', 'Por favor, insira a descrição do evento');
                    isValid = false;
                }
                
                if (!eventImage) {
                    showError('eventImage', 'Por favor, selecione uma imagem de divulgação');
                    isValid = false;
                }
                
                // Se tudo estiver válido, salvar o evento
                if (isValid) {
                    const submitBtn = eventForm.querySelector('.submit-btn');
                    if (submitBtn) {
                        submitBtn.disabled = true;
                        submitBtn.textContent = 'Publicando...';
                    }
                    
                    // Criar objeto do evento
                    // Na parte de validação do formulário de evento, atualize a criação do objeto:
const newEvent = {
    id: Date.now().toString(),
    title: eventTitle,
    date: eventDate,
    startTime: startTime,
    endTime: endTime,
    location: eventLocation,
    chair: eventChair,
    presenter: eventPresenter,
    participants: participants,
    category: eventCategory,
    description: eventDescription,
    createdAt: new Date().toISOString(),
    image: null // Inicializa como null
};

// Processar imagem
if (eventImage) {
    const reader = new FileReader();
    reader.onload = function(e) {
        newEvent.image = e.target.result; // Armazena como base64
        if (salvarEvento(newEvent)) {
            setTimeout(function() {
                alert('Evento publicado com sucesso!');
                window.location.href = 'dashboard.html';
            }, 1000);
        } else {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Publicar';
            alert('Erro ao salvar evento. Tente novamente.');
        }
    };
    reader.readAsDataURL(eventImage);
} else {
    // Se não houver imagem, salva sem imagem
    if (salvarEvento(newEvent)) {
        setTimeout(function() {
            alert('Evento publicado com sucesso!');
            window.location.href = 'dashboard.html';
        }, 1000);
    } else {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Publicar';
        alert('Erro ao salvar evento. Tente novamente.');
    }
}
                }
            });
        }
    }
});